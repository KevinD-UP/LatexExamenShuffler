package org.genial.ark.domain;

public interface ContentExercise {

    @Override
    String toString();


}
