package org.genial.ark.domain.parameterized;

public interface ContentBlock {

    @Override
    String toString();
}
