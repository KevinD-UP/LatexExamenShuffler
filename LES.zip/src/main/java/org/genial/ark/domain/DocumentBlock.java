package org.genial.ark.domain;

public interface DocumentBlock {
    String toString();
}
