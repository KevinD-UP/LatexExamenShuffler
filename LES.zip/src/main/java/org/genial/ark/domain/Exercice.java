package org.genial.ark.domain;

public interface Exercice extends DocumentBlock{

    boolean isFixed();

    String toString();
}
